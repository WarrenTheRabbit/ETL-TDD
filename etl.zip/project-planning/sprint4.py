"""

Ravindar wants an end-to-end demonstration of the ETL pipeline.
 
 
- Create end-to-end demonstration of the ETL pipeline.    SPs: 13
I need help breaking this down into tasks.

Task | Story Points
------------------
Create a AWS Lake Formation database | 5
Crawl the Landing tier data | 1 
Tag the data | 1
Profile the data | 2
Run ETL jobs | 5
Load data into Redshift | 3
Create job triggers | 5 
"""