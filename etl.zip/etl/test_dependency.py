def test_method():
    print("hello world.")