```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject",
                "lakeformation:*"
            ],
            "Resource": "*",
            "Effect": "Allow"
        }
    ]
}
```