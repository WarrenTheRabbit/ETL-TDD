from etl import test_dependency

test_dependency.test_method()