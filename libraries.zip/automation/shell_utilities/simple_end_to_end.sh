#!/bin/bash

python3 batch1.py --JOB_NAME anything && 
python3 batch2.py --JOB_NAME anything &&
python3 batch3.py --JOB_NAME anything &&
python3 batch4.py --JOB_NAME anything &&
python3 batch5.py --JOB_NAME anything