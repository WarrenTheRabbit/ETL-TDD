
from pyspark.sql import SparkSession
from awsglue.context import GlueContext
from pyspark.context import SparkContext
import etl.mock.infrastructure.buckets as project
import etl.jobs.validate.output as validate
import etl.jobs as jobs
# import etl.jobs.validate.expectations.provider as provider
import sys
from etl.mock.process.s3_bucket import get_mock_s3_server_and_its_local_process


def run(spark: SparkSession):
    import stage_source_into_landing
    stage_source_into_landing.run()

    

if __name__ == '__main__':
    
    # if argument ENV is "TEST" then use test spark session
    if sys.argv[1] == 'TEST':
        
        glueContext = GlueContext(SparkContext.getOrCreate())
        spark = glueContext.spark_session
        bucket, process = get_mock_s3_server_and_its_local_process(
                                        spark,
                                        name='test-project',
                                        endpoint_url="http://127.0.0.1:5000/")        
    
       
        project.initialise_for_project(bucket)
        
        run(spark)
        spark.stop()
        sys.exit()
        
    glueContext = GlueContext(SparkContext.getOrCreate())
    spark = glueContext.spark_session
    run(spark)
    spark.stop()