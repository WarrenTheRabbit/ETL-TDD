landing_csv = """provider_id,provider_name,provider_address,provider_phone_number,provider_email_address,provider_type,provider_license_number
558433,Cox and Sons,"695 Ryan Nook, St. Patrick, VIC, 2697",+61 2 4485 8099,rmcdowell@example.org,Pharmacist,82002543
739426,Dillon-Myers,"606 Hamilton Circle, Munozburgh, NT, 2957",+61-3-9481-5525,wmccoy@example.org,General Practitioner,26265469
849574,Thompson-Silva,"Apt. 486 646 Michael Concourse, Lake Gabrielchester, VIC, 2901",+61-416-882-223,jeremyfox@example.com,Specialist,47912254
631140,"Fitzgerald, Moran and Rogers","Level 2 85 Rhonda Upper, Jimmyfurt, TAS, 2987",0446 612 209,terrydeborah@example.org,Physiotherapist,79965027
945989,"Morrison, Palmer and Adams","Flat 00 575 Erica Key, Elizabethbury, NT, 9818",02-2869-3764,matthewssamantha@example.org,Specialist,59185011
"""