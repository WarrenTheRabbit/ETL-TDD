import os
import signal
import subprocess
from pyspark.sql import SparkSession
from etl.paths.components import Bucket
from etl.mock.process import s3_bucket
from etl.mock.infrastructure.buckets import initialise_for_project

def test_stage_claim_into_raw(glueContext):
    
    spark = glueContext.spark_session
    mock_bucket, process = s3_bucket.get_mock_s3_server_and_its_local_process(
                                        spark, 
                                        name=Bucket.PROJECT.value,
                                        endpoint_url="http://127.0.0.1:5000/")   
    
    initialise_for_project(mock_bucket)
    # print all objects in bucket
    for obj in mock_bucket.list_all():
        print(obj)
    
    try:   
        import stage_claim_into_raw
        df = stage_claim_into_raw.run(spark)
        print("***********************************************************")
        df.show()
        
    finally:
        mock_bucket.unload_all()
        os.killpg(os.getpgid(process.pid), signal.SIGTERM)