FROM SYS_LOAD_ERROR_DETAIL

https://docs.aws.amazon.com/redshift/latest/mgmt/serverless-monitoring.html



Spectrum Scan Error. File 'https://s3.ap-southeast-2.amazonaws.com/test-lf-ap/etl/optimised/procedure_dim/full/202306062029/part-00000-43826719-e3eb-4613-ade9-df1f002ea585-c000.snappy.parquet' has an incompatible Parquet schema for column 's3://test-lf-ap/etl/optimised/procedure_dim/full/202306062029/.procedure_key'. Column type: BIGINT, Parquet schema: optional byte_array procedure [i:0 d:1 r:0] (s3://test-lf-ap/etl/optimised/procedure_dim/full/202306062029/part-00000-43826719-e3eb-4613-ade9-df1f002ea585-c


Spectrum Scan Error. Unmatched number of columns between table and file. Table columns: 9, Data columns: 8, File name: https://s3.ap-southeast-2.amazonaws.com/test-lf-ap/etl/optimised/procedure_dim/full/202306062029/part-00000-43826719-e3eb-4613-ade9-df1f002ea585-c000.snappy.parquet (s3://test-lf-ap/etl/optimised/procedure_dim/full/202306062029/part-00000-43826719-e3eb-4613-ade9-df1f002ea585-c000.snappy.parquet)                                                                                                 